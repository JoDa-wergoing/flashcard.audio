package flashcard.audio.models

data class Sentence(
    val id: String,
    val ind: String,
    val nl: String
)
